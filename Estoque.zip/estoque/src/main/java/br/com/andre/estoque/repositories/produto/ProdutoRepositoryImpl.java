package br.com.andre.estoque.repositories.produto;

public class ProdutoRepositoryImpl implements ProtudoRepositoryQuery{
}
