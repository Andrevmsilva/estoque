package br.com.andre.estoque.repositories;

import br.com.andre.estoque.model.Categoria;
import br.com.andre.estoque.repositories.categoria.CategoriaRepositoryQuery;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository <Categoria, Integer>, CategoriaRepositoryQuery {
}
