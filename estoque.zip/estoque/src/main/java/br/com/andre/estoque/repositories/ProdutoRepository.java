package br.com.andre.estoque.repositories;

import br.com.andre.estoque.model.Produto;
import br.com.andre.estoque.repositories.produto.ProdutoRepositoryQuery;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProdutoRepository extends JpaRepository <Produto, Long>, ProdutoRepositoryQuery {
}
