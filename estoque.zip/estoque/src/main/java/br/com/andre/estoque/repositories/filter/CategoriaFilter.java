package br.com.andre.estoque.repositories.filter;

public class CategoriaFilter {
    private String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}

//para fazer o filtro busque na onde vc quer usar se quiser pelo nomne pegue ele e coloque com o mesmo nome da tabela