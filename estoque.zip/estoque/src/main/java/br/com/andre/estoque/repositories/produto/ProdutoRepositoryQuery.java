package br.com.andre.estoque.repositories.produto;

import br.com.andre.estoque.dto.ProdutoDto;
import br.com.andre.estoque.repositories.filter.ProdutoFilter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ProdutoRepositoryQuery {
    public  Page<ProdutoDto> filtrar(ProdutoFilter produtoFilter, Pageable pageable);
}
